const question = [
    {
      category: "Pipes and cisterns",
      Quizwrap: [
        {
          id:1,
          question:
            "A tank is filled by three pipes with uniform flow. The first two pipes operating simultaneously fill the tank in the same time during which the tank is filled by the third pipe alone. The second pipe fills the tank 5 hours faster than the first pipe and 4 hours slower than the third pipe. The time required by the first pipe is?",
          option: ["6 Hours", "10 Hours", "15 Hours", "30 Hours"],
          answer: 3,
        },
  
        {
          id:2,
          question:
            "Two pipes A and B can fill a tank in 20 and 30 minutes respectively. If both the pipes are used together, then how long will it take to fill the tank?",
          option: ["12 min", "15 min", "25 min", "50 min"],
          answer: 1,
        },
  
        {
          id:3,
          question:
            "Two pipes can fill a tank in 20 and 24 minutes respectively and a waste pipe can empty 3 gallons per minute. All the three pipes working together can fill the tank in 15 minutes. The capacity of the tank is?",
          option: ["60 gallons", "100 gallons", "120 gallons", "180 gallons"],
          answer: 3,
        },
  
        {
          id:4,
          question:
            "A tank is filled in 5 hours by three pipes A, B and C. The pipe C is twice as fast as B and B is twice as fast as A. How much time will pipe A alone take to fill the tank?",
          option: ["20 hours", "25 hours", "35 hours", "Cannot be determined"],
          answer: 4,
        },
  
        {
          id:5,
          question:
            "A tank is filled by three pipes with uniform flow. The first two pipes operating simultaneously fill the tank in the same time during which the tank is filled by the third pipe alone. The second pipe fills the tank 5 hours faster than the first pipe and 4 hours slower than the third pipe. The time required by the first pipe is?",
          option: ["6 Hours", "10 Hours", "15 Hours", "30 Hours"],
          answer: 3,
        },
  
        {
          id:6,
          question:
            "Two pipes A and B together can fill a cistern in 4 hours. Had they been opened separately, then B would have taken 6 hours more than A to fill the cistern. How much time will be taken by A to fill the cistern separately?",
          option: ["1 Hours", "2 Hours", "6 Hours", "8 Hours"],
          answer: 3,
        },
  
        {
          id:7,
          question:
            "Two pipes A and B can fill a tank in 20 and 30 minutes respectively. If both the pipes are used together, then how long will it take to fill the tank?",
          option: ["12 min", "15 min", "25 min", "50 min"],
          answer: 1,
        },
  
        {
          id:8,
          question:
            "Two pipes can fill a tank in 20 and 24 minutes respectively and a waste pipe can empty 3 gallons per minute. All the three pipes working together can fill the tank in 15 minutes. The capacity of the tank is?",
          option: ["60 gallons", "100 gallons", "120 gallons", "180 gallons"],
          answer: 3,
        },
  
        {
          id:9,
          question:
            "One pipe can fill a tank three times as fast as another pipe. If together the two pipes can fill the tank in 36 minutes, then the slower pipe alone will be able to fill the tank in?",
          option: ["81 min.", "108 min", "144 min", "192 min"],
          answer: 3,
        },
  
        {
          id:10,
          question:
            "A large tanker can be filled by two pipes A and B in 60 minutes and 40 minutes respectively. How many minutes will it take to fill the tanker from empty state if B is used for half the time and A and B fill it together for the other half?",
          option: ["15 min", "20 min", "27.5 min", "30 min  "],
          answer: 4,
        },
      ],
    },
    {
      category: "Problem on Ages",
      Quizwrap: [
        {
          id:1,
          question:
            "The sum of ages of 5 children born at the intervals of 3 years each is 50 years. What is the age of the youngest child?",
          option: ["4 years", "8 years", "10 years", "None of these"],
          answer: 1,
        },
  
        {
          id:2,
          question:
            "A father said to his son, 'I was as old as you are at the present at the time of your birth'. If the father's age is 38 years now, the son's age five years back was?",
          option: ["14 years", "19 years", "33 years", "38 years"],
          answer: 1,
        },
  
        {
          id:3,
          question:
            "A is two years older than B who is twice as old as C. If the total of the ages of A, B and C be 27, then how old is B?",
          option: ["7", "8", "9", "10"],
          answer: 4,
        },
  
        {
          id:4,
          question:
            "A man is 24 years older than his son. In two years, his age will be twice the age of his son. The present age of his son is:?",
          option: ["14 years", "18 years", "20 years", "22 years"],
          answer: 4,
        },
  
        {
          id:5,
          question:
            "The sum of ages of 5 children born at the intervals of 3 years each is 50 years. What is the age of the youngest child?",
          option: ["4 years", "8 years", "10 years", "None of these"],
          answer: 1,
        },
  
        {
          id:6,
          question:
            "A father said to his son, 'I was as old as you are at the present at the time of your birth'. If the father's age is 38 years now, the son's age five years back was?",
          option: ["14 years", "19 years", "33 years", "38 years"],
          answer: 1,
        },
  
        {
          id:7,
          question:
            "The sum of the present ages of a father and his son is 60 years. Six years ago, father's age was five times the age of the son. After 6 years, son's age will be:?",
          option: ["12 years", "14 years", "18 years", "20 years"],
          answer: 4,
        },
  
        {
          id:8,
          question:
            "A is two years older than B who is twice as old as C. If the total of the ages of A, B and C be 27, then how old is B?",
          option: ["7", "8", "9", "10"],
          answer: 4,
        },
  
        {
          id:9,
          question:
            "At present, the ratio between the ages of Arun and Deepak is 4 : 3. After 6 years, Arun's age will be 26 years. What is the age of Deepak at present ?",
          option: ["12 years", "15 years", "19 and half", "21 years"],
          answer: 2,
        },
  
        {
          id:10,
          question:
            "Sachin is younger than Rahul by 7 years. If their ages are in the respective ratio of 7 : 9, how old is Sachin?",
          option: ["16 years", "18 years", "28 years", "24.5 years"],
          answer: 4,
        },
      ],
    },
    {
      category: "Profit and Lose",
      Quizwrap: [
        {
          id: 1,
          question:
            "The cost price of 20 articles is the same as the selling price of x articles. If the profit is 25%, then the value of x is:?",
          option: ["15", "16", "18", "25"],
          answer: 2,
        },
  
        {
          id: 2,
          question:
            "In a certain store, the profit is 320% of the cost. If the cost increases by 25% but the selling price remains constant, approximately what percentage of the selling price is the profit?",
          option: ["30%", "70%", "100%", "250%"],
          answer: 2,
        },
  
        {
          id: 3,
          question:
            "A vendor bought toffees at 6 for a rupee. How many for a rupee must he sell to gain 20%?",
          option: ["3", "4", "5", "6"],
          answer: 3,
        },
  
        {
          id: 4,
          question:
            "A shopkeeper expects a gain of 22.5% on his cost price. If in a week, his sale was of Rs. 392, what was his profit?",
          option: ["Rs. 18.20", "Rs. 72", "Rs. 70", "Rs. 88.25"],
          answer: 3,
        },
  
        {
          id: 5,
          question:
            "The cost price of 20 articles is the same as the selling price of x articles. If the profit is 25%, then the value of x is:?",
          option: ["15", "16", "18", "25"],
          answer: 2,
        },
  
        {
          id: 6,
          question:
            "In a certain store, the profit is 320% of the cost. If the cost increases by 25% but the selling price remains constant, approximately what percentage of the selling price is the profit?",
          option: ["30%", "70%", "100%", "250%"],
          answer: 2,
        },
  
        {
          id: 7,
          question:
            "A man buys a cycle for Rs. 1400 and sells it at a loss of 15%. What is the selling price of the cycle?",
          option: ["Rs. 1090", "Rs. 1160", "Rs. 1190", "Rs. 1202"],
          answer: 3,
        },
  
        {
          id: 8,
          question:
            "Sam purchased 20 dozens of toys at the rate of Rs. 375 per dozen. He sold each one of them at the rate of Rs. 33. What was his percentage profit?",
          option: ["3.5", "4.5", "5.6", "6.5"],
          answer: 3,
        },
  
        {
          id: 9,
          question:
            "A vendor bought toffees at 6 for a rupee. How many for a rupee must he sell to gain 20%?",
          option: ["3", "4", "5", "6"],
          answer: 3,
        },
  
        {
          id: 10,
          question:
            "On selling 17 balls at Rs. 720, there is a loss equal to the cost price of 5 balls. The cost price of a ball is:",
          option: ["Rs. 45", "Rs. 50", "Rs. 55", "Rs. 60"],
          answer: 4,
        },
      ],
    },
    {
      category: "Probability",
      Quizwrap: [
        {
          id:1,
          question:
            "Tickets numbered 1 to 20 are mixed up and then a ticket is drawn at random. What is the probability that the ticket drawn has a number which is a multiple of 3 or 5?",
          option: ["1/2", "2/5", "8/15", "9/20"],
          answer: 4,
        },
  
        { id:2,
          question:
            "A bag contains 2 red, 3 green and 2 blue balls. Two balls are drawn at random. What is the probability that none of the balls drawn is blue?",
          option: ["10/21", "11/21", "2/7", "5/7"],
          answer: 1,
        },
  
        {
          id:3,
          question:
            "In a box, there are 8 red, 7 blue and 6 green balls. One ball is picked up randomly. What is the probability that it is neither red nor green?",
          option: ["1/3", "3/4", "7/19", "8/21"],
          answer: 1,
        },
  
        {
          id:4,
          question:
            "What is the probability of getting a sum 9 from two throws of a dice?",
          option: ["1/6", "1/8", "1/9", "1/12"],
          answer: 3,
        },
  
        {
          id:5,
          question:
            "Tickets numbered 1 to 20 are mixed up and then a ticket is drawn at random. What is the probability that the ticket drawn has a number which is a multiple of 3 or 5?",
          option: ["1/2", "2/5", "8/15", "9/20"],
          answer: 4,
        },
  
        {
          id:6,
          question:
            "A bag contains 2 red, 3 green and 2 blue balls. Two balls are drawn at random. What is the probability that none of the balls drawn is blue?",
          option: ["10/21", "11/21", "2/7", "5/7"],
          answer: 1,
        },
  
        {
          id:7,
          question:
            "In a box, there are 8 red, 7 blue and 6 green balls. One ball is picked up randomly. What is the probability that it is neither red nor green?",
          option: ["1/3", "3/4", "7/19", "8/21"],
          answer: 1,
        },
  
        {
          id:8,
          question:
            "Three unbiased coins are tossed. What is the probability of getting at most two heads?",
          option: ["3/4", "1/4", "3/8", "7/8"],
          answer: 4,
        },
  
        {
          id:9,
          question:
            "Tickets numbered 1 to 20 are mixed up and then a ticket is drawn at random. What is the probability that the ticket drawn has a number which is a multiple of 3 or 5?",
          option: ["1/2", "2/5", "8/15", "9/20"],
          answer: 4,
        },
  
        {
          id:10,
          question:
            "A bag contains 2 red, 3 green and 2 blue balls. Two balls are drawn at random. What is the probability that none of the balls drawn is blue?",
          option: ["10/21", "11/21", "2/7", "5/7"],
          answer: 1,
        },
      ],
    },
  ];
  

  
