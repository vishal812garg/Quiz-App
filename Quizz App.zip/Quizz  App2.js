let userName;
let User = () =>{
  userName = document.getElementById("username").value;
  let btn = document.querySelector(".category-box");
  btn.style.display = "block"; 
} 
document.getElementById("enter").addEventListener("click", User);

function selectedcategory(category){
 let mainbox = document.querySelector(".custom-box-show");
 let quizbox = document.querySelector(".quiz-box");
 mainbox.style.display = "none";
 quizbox.style.display = "block";
 
 let data = question.filter((ele,i) => ele.category == category)[0];
 
  let quizoverbox = document.querySelector(".quiz-over-box") 
  let categoryText = document.querySelector(".category-text");
  let questionNum = document.querySelector(".current-question-num");
  let questionText = document.querySelector(".question-text");
  let optionBox = document.querySelector(".option-box");
  let nextBtn = document.querySelector(".next-question-btn");
  let scoreBox = document.querySelector(".score-text");
  let seeResult = document.querySelector(".see-result-btn");
      seeResult.disabled = true; 
  let resultBox = document.querySelector(".quiz-over-box");
  let result = document.querySelector(".quiz-result");
  let totalQuestions = document.querySelector(".total-questions");
  let totalAttempted = document.querySelector(".total-attempt");
  let totalCurrect = document.querySelector(".total-correct");
  let totalWrong = document.querySelector(".total-wrong");
  let per=document.querySelector(".percentage");
  let quizTime=document.querySelector(".quiz-time");
  let timeTaken=document.querySelector(".taken-time");

  let startAgain = document.querySelector(".start-again-quiz-btn");
  let currentScore = 0;
  let currentQuestion = 1;
  let attemptedCount = 0;
  let n;
  let timer=300;

  let inter = setInterval(function(){
    quizTime.innerHTML = timer;
    timer--;
    n=timer;
    if(timer==0){
      clearInterval(inter);
      appendResult();
    }
  },1000); 

  let appendQuestion = () => {
    optionBox.innerHTML = null;
    categoryText.innerHTML = category;
    let currentQuestionData = data.Quizwrap[currentQuestion - 1];
    console.log(currentQuestionData, "current question");
    questionNum.innerHTML = `${currentQuestionData.id}/10`;
    questionText.innerHTML = currentQuestionData.question;
    scoreBox.innerHTML = `Score: ${currentScore}`;
    for(let i = 0; i < currentQuestionData.option.length; i++){
      let opt = document.createElement("button");
      opt.setAttribute("class" , "options");
      opt.innerText = currentQuestionData.option[i];
      opt.dataset.ans = currentQuestionData.answer == i + 1 ? true : false;
      opt.addEventListener("click" , function(event){
        checkans(event);
      })
      optionBox.append(opt);
    }
  }
  appendQuestion();


    function checkans(event){
      const {ans} = event.target.dataset;
      attemptedCount += 1;
      console.log(attemptedCount, "attemptedCount");
      
      if(ans == "true"){
        event.target.style.background = "green";
        event.target.style.color = "white";
        currentScore += 1;
        scoreBox.innerText = `Score: ${currentScore}`;
      }
      else {
        event.target.style.background = "red";
        event.target.style.color = "white";
      }
      let options = document.querySelectorAll(".options");
      console.log(options);
      options.forEach((el) => (el.disabled = true));
      options.forEach((el) => {
        if(el.dataset.ans == "true") {
          el.style.background = "green";
        }
      });
   }  

   function appendResult(){
      clearInterval(inter);
      quizbox.style.display = "none";
      resultBox.style.display = "block";
      timeTaken.innerText = `${300-n}`;
      result.innerText = `${userName} you result is: ${currentScore}`;   
      result.style.fontSize = "25px";
      totalQuestions.innerText = currentQuestion;
      totalAttempted.innerText = attemptedCount;
      totalCurrect.innerText = currentScore;
      let percentage = (currentScore/10)*100;
      per.innerText = `${percentage}%`;
      totalWrong.innerText =currentQuestion - currentScore;
   }


   nextBtn.addEventListener("click", function(){
     if(currentQuestion < 10){
      currentQuestion += 1;
      appendQuestion();
     }
     if(currentQuestion >= 10){
        seeResult.disabled = false;
      }
      else{
        seeResult.disabled = true;
     }
   });

   seeResult.addEventListener("click", function(){
    appendResult();
   });

   startAgain.addEventListener("click",function(){
    selectedcategory(category);
    quizoverbox.style.display = "none";
   });

   let goToHome = document.querySelector(".go-home-btn");
     goToHome.addEventListener("click",function(){
     mainbox.style.display = "block";
     quizbox.style.display = "none";
     quizoverbox.style.display = "none"; 
   });
}
